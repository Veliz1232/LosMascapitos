/* =========================
   Inicialización y utilidades
========================= */
(function () {
  document.addEventListener('DOMContentLoaded', function () {
    if (window.M && M.AutoInit) M.AutoInit();

    const sidenavs = document.querySelectorAll('.sidenav');
    if (window.M && M.Sidenav) M.Sidenav.init(sidenavs);

    const y = document.getElementById('year');
    if (y) y.textContent = new Date().getFullYear();

    // Navegación por data-url
    document.querySelectorAll('.redirigir').forEach(btn => {
      btn.addEventListener('click', () => {
        const url = btn.getAttribute('data-url');
        if (url) window.location.href = url;
      });
    });

    // Helpers opcionales
    const goHome1 = document.getElementById('bt1');
    if (goHome1) goHome1.addEventListener('click', () => (window.location.href = 'home.html'));
    const goHome2 = document.getElementById('bt2');
    if (goHome2) goHome2.addEventListener('click', () => (window.location.href = 'home.html'));
    const goCaso1 = document.getElementById('bt3');
    if (goCaso1) goCaso1.addEventListener('click', () => (window.location.href = 'caso1.html'));
    const goCaso2 = document.getElementById('bt4');
    if (goCaso2) goCaso2.addEventListener('click', () => (window.location.href = 'caso2.html'));

    // Delegación: botones .add-to-cart con data-name, data-price y opcional data-qty="#id"
    document.body.addEventListener('click', (e) => {
      const btn = e.target.closest('.add-to-cart');
      if (!btn) return;
      const nombre = btn.dataset.name || null;
      const precio = btn.dataset.price ? parseInt(btn.dataset.price, 10) : NaN;
      const qtySel = btn.dataset.qty ? document.querySelector(btn.dataset.qty) : null;
      const cantidad = qtySel ? clampQty(qtySel.value) : 1;
      if (!nombre || !Number.isFinite(precio)) {
        alert('Botón sin datos de producto.');
        return;
      }
      Cart.add(nombre, precio, cantidad);
    });

    // Pintar contador/tabla si existen
    Cart.updateCartUI();
  });
})();

const REGEX_CORREO = /^[^\s@]+@(duocuc\.cl|profesor\.duoc\.cl|gmail\.com)$/;
const PASS_MIN = 4;
const PASS_MAX = 10;

const Dom = {
  el: (id) => document.getElementById(id),
  txt: (sel) => {
    const el = document.querySelector(sel);
    return el ? el.textContent.trim() : '';
  }
};

const fmtCLP = (n) =>
  new Intl.NumberFormat('es-CL', { style: 'currency', currency: 'CLP', maximumFractionDigits: 0 }).format(n);

const parseCLP = (s) => {
  if (typeof s !== 'string') return NaN;
  const onlyDigits = s.replace(/[^\d]/g, '');
  return onlyDigits ? parseInt(onlyDigits, 10) : NaN;
};

const clampQty = (v) => {
  const n = parseInt(v, 10);
  return Number.isFinite(n) && n > 0 ? n : 1;
};

/* =========================
   Carrito con localStorage
========================= */
const CART_KEY = 'pm_cart';

const Cart = {
  load() {
    try {
      const raw = localStorage.getItem(CART_KEY);
      const arr = JSON.parse(raw);
      return Array.isArray(arr) ? arr : [];
    } catch { return []; }
  },
  save(items) { localStorage.setItem(CART_KEY, JSON.stringify(items || [])); },
  all() { return this.load(); },
  add(nombre, precio, cantidad) {
    const items = this.load();
    const idx = items.findIndex(p => p.nombre === nombre);
    if (idx >= 0) items[idx].cantidad += cantidad;
    else items.push({ nombre, precio, cantidad });
    this.save(items);
    this.updateCartUI();
    if (window.M && M.toast) M.toast({ html: `${nombre} añadido: ${fmtCLP(precio)} x ${cantidad}`, classes: 'teal' });
  },
  removeAt(index) {
    const items = this.load();
    if (index >= 0 && index < items.length) items.splice(index, 1);
    this.save(items);
    this.updateCartUI();
  },
  clear() { this.save([]); this.updateCartUI(); },
  count() { return this.load().reduce((acc, it) => acc + (it.cantidad || 0), 0); },
  total() { return this.load().reduce((acc, it) => acc + (it.precio || 0) * (it.cantidad || 0), 0); },
  updateCartUI() {
    // badges
    const count = this.count();
    const b1 = document.getElementById('cart-count');
    const b2 = document.getElementById('cart-count-mobile');
    if (b1) b1.textContent = count;
    if (b2) b2.textContent = count;

    // tabla carrito si existe
    const cartItems = document.getElementById('cart-items');
    const cartTotal = document.getElementById('cart-total');
    if (!cartItems || !cartTotal) return;

    const items = this.load();
    cartItems.innerHTML = '';
    items.forEach((item, index) => {
      const subtotal = item.precio * item.cantidad;
      cartItems.insertAdjacentHTML('beforeend', `
        <tr>
          <td>${item.nombre}</td>
          <td>${fmtCLP(item.precio)}</td>
          <td>${item.cantidad}</td>
          <td>${fmtCLP(subtotal)}</td>
          <td><button class="btn red" data-del="${index}"><i class="material-icons">delete</i></button></td>
        </tr>
      `);
    });
    cartTotal.textContent = fmtCLP(this.total());

    cartItems.querySelectorAll('[data-del]').forEach(btn => {
      btn.addEventListener('click', () => {
        const idx = parseInt(btn.getAttribute('data-del'), 10);
        Cart.removeAt(idx);
      });
    });
  }
};

// Compatibilidad: actualizar contador/tabla manualmente
function updateCart() { Cart.updateCartUI(); }

/* =========================
   addToCart flexible
   - Si se llama con parámetros: usa esos valores
   - Si se llama sin parámetros: infiere de la página de producto:
        nombre => <h4> del producto
        precio => primer elemento con clase .teal-text (p.ej. "$100.000")
        cantidad => #cantidad
========================= */
function addToCart(nombre, precio, cantidadInputId) {
  // Llamado parametrizado
  if (nombre && Number.isFinite(precio)) {
    let cantidad = 1;
    if (cantidadInputId) {
      const el = document.getElementById(cantidadInputId);
      if (el) cantidad = clampQty(el.value);
    }
    Cart.add(nombre, precio, cantidad);
    return;
  }

  // Llamado sin parámetros: inferir desde DOM de la página de producto
  const inferredName = Dom.txt('h4') || Dom.txt('h1') || Dom.txt('[data-product-name]');
  const priceText =
    Dom.txt('.teal-text') ||
    Dom.txt('[data-product-price]') ||
    Dom.txt('.price') ||
    Dom.txt('.product-price');
  const qtyEl = document.getElementById('cantidad');

  const inferredPrice = parseCLP(priceText);
  const cantidad = qtyEl ? clampQty(qtyEl.value) : 1;

  if (!inferredName || !Number.isFinite(inferredPrice)) {
    alert('No fue posible obtener los datos del producto.');
    return;
  }

  Cart.add(inferredName, inferredPrice, cantidad);
}

function eliminarItem(index) { Cart.removeAt(index); }

function finalizarCompra() {
  const items = Cart.all();
  if (!items.length) { alert('Tu carrito está vacío'); return; }
  alert('Compra finalizada con éxito');
  if (window.M && M.toast) M.toast({ html: 'Compra finalizada', classes: 'teal' });
  Cart.clear();
}
