function registrar() {

    let correo = document.getElementById("Correo");
    let repetirCorreo = document.getElementById("RepetirCorreo");
    let contra = document.getElementById("Contraseña");
    let confirmarPass = document.getElementById("ConfirmarContraseña");
    let nombreCompleto = document.getElementById("fullName");

    if(nombreCompleto.value.trim()==""){
        alert("Ingresa un nombre valido")
        nombreCompleto.focus();
    }

    if(nombreCompleto.length>=100){
        alert("solo se permite un maximo de 100 caracteres")
    }

    if(correo.value.trim()==""){
        alert("Ingresa un correo valido")
        correo.focus();
    }

    let regexCorreo = /^[^\s@]+@(duoc\.cl|profesor\.duoc\.cl|gmail\.com)$/;
    if (!regexCorreo.test(correo)) {
        alert("Solo se permiten correos @duoc.cl, @profesor.duoc.cl o @gmail.com");
    return;
    }

    if(correo.length>=100){
        alert("solo se permite un maximo de 100 caracteres")
    }

    if (correo !== repetirCorreo) {
        alert("Los correos no coinciden");
        return;
    }

    if(contra.value.trim()==""){
        alert("Ingresa una contraseña valida")
        contra.focus();
    }

    if (contra.length <= 4 ) {
        alert("La contraseña debe tener al menos 4 caracteres");
        return;
    }

    if (contra.length >= 10 ) {
        alert("La contraseña debe tener menos de 10 caracteres");
        return;
    }

    if (contra !== confirmarPass) {
        alert("Las contraseñas no coinciden");
        return;
    }

    // Si todo está OK
    alert("Registro exitoso");

    document.getElementById('2').addEventListener('click', function() {
    window.location.href = 'home.html';
    });


}

function EnviarMensaje(){

    let contenido = document.getElementById("Contenido");
    let correo = document.getElementById("Correo");
    let nombreCompleto = document.getElementById("fullName");

    if(nombreCompleto.value.trim()==""){
        alert("Ingresa un nombre valido")
        nombreCompleto.focus();
    }

    if(nombreCompleto.length>=100){
        alert("solo se permite un maximo de 100 caracteres")
    }

    if(correo.value.trim()==""){
        alert("Ingresa un correo valido")
        correo.focus();
    }

    let regexCorreo = /^[^\s@]+@(duoc\.cl|profesor\.duoc\.cl|gmail\.com)$/;
    if (!regexCorreo.test(correo)) {
        alert("Solo se permiten correos @duoc.cl, @profesor.duoc.cl o @gmail.com");
    return;
    }

    if(correo.length>=100){
        alert("solo se permite un maximo de 100 caracteres")
    }

    if(contenido.value.trim()==""){
        alert("Ingresa el mensaje")
        contenido.focus();
    }

    if(contenido.length>=500){
        alert("solo se permite un maximo de 500 caracteres")
    }

    alert("mensaje enviado con exito")
    
}

function iniciosesion(){
    
    let correo = document.getElementById("correo");
    let contra = document.getElementById("pass");

    if(correo.value.trim()==""){
        alert("Ingresa un correo valido")
        correo.focus();
    }

    let regexCorreo = /^[^\s@]+@(duoc\.cl|profesor\.duoc\.cl|gmail\.com)$/;
    if (!regexCorreo.test(correo)) {
        alert("Solo se permiten correos @duoc.cl, @profesor.duoc.cl o @gmail.com");
    return;
    }
    
    if(correo.length>=100){
        alert("solo se permite un maximo de 100 caracteres")
    }

    if(contra.value.trim()==""){
        alert("Ingresa una contraseña valida")
        contra.focus();
    }

    if (contra.length <= 4 ) {
        alert("La contraseña debe tener al menos 4 caracteres");
        return;
    }

    if (contra.length >= 10 ) {
        alert("La contraseña debe tener menos de 10 caracteres");
        return;
    }

    
    document.getElementById('1').addEventListener('click', function() {
    window.location.href = 'home.html';
    });
}

document.getElementById('3').addEventListener('click', function() {
window.location.href = 'caso1.html';
});

document.getElementById('4').addEventListener('click', function() {
window.location.href = 'caso2.html';
});


document.addEventListener('DOMContentLoaded', function() {
    M.Sidenav.init(document.querySelectorAll('.sidenav'));
    document.getElementById("year").textContent = new Date().getFullYear();
    updateCart();
    });

function updateCart(count) {
    document.getElementById('cart-count').textContent = count;
    document.getElementById('cart-count-mobile').textContent = count;
}

document.querySelectorAll(".redirigir").forEach(function(boton) {
    boton.addEventListener("click", function() {
    let url = this.getAttribute("data-url"); 
    if (url) {
        window.location.href = url; 
    }
    });
});