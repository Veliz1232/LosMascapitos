function registrar() {
    let nombreCompleto = document.getElementById("fullName");
    let correo = document.getElementById("Correo");
    let repetirCorreo = document.getElementById("RepetirCorreo");
    let contra = document.getElementById("Contraseña");
    let confirmarPass = document.getElementById("ConfirmarContraseña");

    if (nombreCompleto.value.trim() == "") {
        alert("Ingresa un nombre válido");
        nombreCompleto.focus();
        return;
    }
    if (nombreCompleto.value.length > 100) {
        alert("Solo se permite un máximo de 100 caracteres");
        return;
    }

    if (correo.value.trim() == "") {
        alert("Ingresa un correo válido");
        correo.focus();
        return;
    }

    let regexCorreo = /^[^\s@]+@(duocuc\.cl|profesor\.duoc\.cl|gmail\.com)$/;
    if (!regexCorreo.test(correo.value)) {
        alert("Solo se permiten correos @duoc.cl, @profesor.duoc.cl o @gmail.com");
        return;
    }
    if (correo.value.length > 100) {
        alert("Solo se permite un máximo de 100 caracteres");
        return;
    }
    if (correo.value !== repetirCorreo.value) {
        alert("Los correos no coinciden");
        return;
    }

    if (contra.value.trim() == "") {
        alert("Ingresa una contraseña válida");
        contra.focus();
        return;
    }
    if (contra.value.length < 4) {
        alert("La contraseña debe tener al menos 4 caracteres");
        return;
    }
    if (contra.value.length > 10) {
        alert("La contraseña debe tener menos de 10 caracteres");
        return;
    }
    if (contra.value !== confirmarPass.value) {
        alert("Las contraseñas no coinciden");
        return;
    }

    alert("Registro exitoso");
    document.getElementById('bt2').addEventListener('click', function() {
    window.location.href = 'home.html';
    });
}


function EnviarMensaje() {
    let contenido = document.getElementById("Contenido");
    let correo = document.getElementById("Correo");
    let nombreCompleto = document.getElementById("fullName");

    if (nombreCompleto.value.trim() == "") {
        alert("Ingresa un nombre válido");
        nombreCompleto.focus();
        return;
    }

    if (nombreCompleto.value.length >= 100) {
        alert("Solo se permite un máximo de 100 caracteres para el nombre");
        return;
    }

    if (correo.value.trim() == "") {
        alert("Ingresa un correo válido");
        correo.focus();
        return;
    }

    let regexCorreo = /^[^\s@]+@(duocuc\.cl|profesor\.duoc\.cl|gmail\.com)$/;
    if (!regexCorreo.test(correo.value)) {
        alert("Solo se permiten correos @duoc.cl, @profesor.duoc.cl o @gmail.com");
        return;
    }

    if (correo.value.length >= 100) {
        alert("Solo se permite un máximo de 100 caracteres para el correo");
        return;
    }

    if (contenido.value.trim() == "") {
        alert("Ingresa el mensaje");
        contenido.focus();
        return;
    }

    if (contenido.value.length >= 500) {
        alert("Solo se permite un máximo de 500 caracteres para el mensaje");
        return;
    }

    alert("Mensaje enviado con éxito");
}


function iniciosesion() {
    let correo = document.getElementById("correo");
    let contra = document.getElementById("pass");

    if (correo.value.trim() == "") {
        alert("Ingresa un correo válido");
        correo.focus();
        return;
    }

    let regexCorreo = /^[^\s@]+@(duocuc\.cl|profesor\.duoc\.cl|gmail\.com)$/;
    if (!regexCorreo.test(correo.value)) {
        alert("Solo se permiten correos @duoc.cl, @profesor.duoc.cl o @gmail.com");
        return;
    }

    if (correo.value.length >= 100) {
        alert("Solo se permite un máximo de 100 caracteres");
        return;
    }

    if (contra.value.trim() == "") {
        alert("Ingresa una contraseña válida");
        contra.focus();
        return;
    }

    if (contra.value.length <= 4) {
        alert("La contraseña debe tener al menos 4 caracteres");
        return;
    }
    if (contra.value.length >= 10) {
        alert("La contraseña debe tener menos de 10 caracteres");
        return;
    }

    document.getElementById('bt1').addEventListener('click', function() {
    window.location.href = 'home.html';
    });
}

document.getElementById('bt3').addEventListener('click', function() {
window.location.href = 'caso1.html';
});

document.getElementById('bt4').addEventListener('click', function() {
window.location.href = 'caso2.html';
});

let carrito = [];

// ================== CARRITO ==================
function updateCart() {
    let cartCount = carrito.reduce((acc, item) => acc + item.cantidad, 0);
    document.getElementById("cart-count").textContent = cartCount;
    document.getElementById("cart-count-mobile").textContent = cartCount;

    let cartItems = document.getElementById("cart-items");
    let cartTotal = document.getElementById("cart-total");
    if (!cartItems || !cartTotal) return; 

    cartItems.innerHTML = "";
    let total = 0;

    carrito.forEach((item, index) => {
        let subtotal = item.precio * item.cantidad;
        total += subtotal;

        cartItems.innerHTML += `
            <tr>
                <td>${item.nombre}</td>
                <td>$${item.precio}</td>
                <td>${item.cantidad}</td>
                <td>$${subtotal}</td>
                <td><button class="btn red" onclick="eliminarItem(${index})"><i class="material-icons">delete</i></button></td>
            </tr>
        `;
    });

    cartTotal.textContent = total;
}

function addToCart() {
    let cantidad = parseInt(document.getElementById("cantidad").value);
    let nombre = "Phantome";
    let precio = 95000;

    let item = carrito.find(p => p.nombre === nombre);
    if (item) {
        item.cantidad += cantidad;
    } else {
        carrito.push({ nombre, precio, cantidad });
    }

    updateCart();
    M.toast({html: 'Producto añadido al carrito!', classes: 'teal'});
}

function eliminarItem(index) {
    carrito.splice(index, 1);
    updateCart();
}

function finalizarCompra() {
    if (carrito.length === 0) {
        alert("Tu carrito está vacío");
        return;
    }
    alert("¡Compra finalizada con éxito!");
    carrito = [];
    updateCart();
}


// ================== INICIALIZACIÓN ==================
document.addEventListener('DOMContentLoaded', function() {
    M.AutoInit();
    document.getElementById("year").textContent = new Date().getFullYear();
    updateCart();
});