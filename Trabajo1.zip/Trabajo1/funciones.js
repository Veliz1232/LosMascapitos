<script>
  document.querySelectorAll(".redirigir").forEach(function(boton) {
    boton.addEventListener("click", function() {
      let url = this.getAttribute("data-url"); 
      if (url) {
        window.location.href = url; 
      }
    });
  });
</script>