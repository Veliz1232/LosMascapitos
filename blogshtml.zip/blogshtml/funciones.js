function botonesVerCaso(){
    let botonesVerCaso = document.getElementById("boton-mediano");
}






















const botonesVerCaso = document.getElementById('.boton-mediano');

botonesVerCaso.forEach((boton, index) => {
  boton.addEventListener('click', () => {
    

    alert(`¡Estás viendo el caso curioso ${index + 1}!`);

 
  });
});
